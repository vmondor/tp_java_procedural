package fr.mondor.util;

import fr.mondor.obj.Phrases;

public class Sentence {

	public static void main(String[] args) {
		Phrases phrase = new Phrases();
		phrase.deleteCharacSentence();
	}
}
