package fr.mondor.demoswing;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.awt.event.ItemEvent;
//import java.awt.event.ItemListener;
//import java.awt.event.MouseListener;
//import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Fenetre {

	private static JButton bouton = new JButton("Ok");
	private static JPanel conteneur = new JPanel();
	private static JTextField texteInput = new JTextField("Zone de texte");
	private static JComboBox<String> combo = new JComboBox<String>();
	private static JLabel texte = new JLabel();
	
	public void fenetre () {
		
		
		JFrame maFenetre = new JFrame();
		// Fixer la taille de la fenetre(width, height)
		maFenetre.setSize(400, 300);
		// Empecher la redimension de la fenetre par l'utilisateur
		maFenetre.setResizable(false);
		// Afficher la fenetre au milieu de l'�cran
		maFenetre.setLocationRelativeTo(null);
		// Fermeture de la fenetre lorsque l'utilisateur appuis sur la croix
		maFenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Set le titre de la fenetre
		maFenetre.setTitle("Titre de ma fenetre");
		// Ajout bouton sur le conteneur
		conteneur.add(bouton);
		// Ajout zone de texte
		conteneur.add(texteInput);
		// Ajout d'�l�ment dans combo box et ajout de comboBox 
		combo.addItem("Item1");
		combo.addItem("Item2");
		combo.addItem("Item3");
		combo.addItem("Item4");
		conteneur.add(combo);
		
		texte.setText("Voici mon label");
		conteneur.add(texte);
		
		/**
		bouton.addActionListener(new ActionListener() {
			int compteur = 0;
			public void actionPerformed(ActionEvent e) {
				compteur++;
				System.out.println("Vous avez cliqu� sur le bouton " + compteur + " fois.");
			}
		});
		
		combo.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					System.out.println("choix : " + e.getItem());
				}
			}
		});
		
		texte.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("Vous avez cliqu� sur le label");
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		**/
		
		// Ajout contentPane conteneur � ma fenetre
		maFenetre.setContentPane(conteneur);
		// Afficher la fenetre
		maFenetre.setVisible(true);
	}
	
	

}
