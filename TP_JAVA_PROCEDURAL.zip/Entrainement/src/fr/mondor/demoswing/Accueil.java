package fr.mondor.demoswing;

public class Accueil {
	
	public static void main(String[] args) {
		
		Fenetre maFenetre = new Fenetre();
		maFenetre.fenetre();
	}

}
