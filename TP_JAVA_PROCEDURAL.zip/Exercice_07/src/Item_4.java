import java.math.BigDecimal;

public class Item_4 {

	public static void main(String[] args) {
		double deux = 456789.7890123456789;
		char chara = (char) deux;
		int inte = (int) deux;
		float floater = (float) deux;
		byte bt = (byte) deux;
		short sht = (short) deux;
		long lg = (long) deux;
		
		System.out.println("double : " + deux);
		System.out.println("char : " + chara);
		System.out.println("int : " + inte);
		System.out.println("float : " + floater);
		System.out.println("byte : " + bt);
		System.out.println("short : " + sht);
		System.out.println("short : " + lg);
	}

}
