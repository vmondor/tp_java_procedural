

public class Item_2 {

	public static void main(String[] args) {
		StringBuffer tab1 = new StringBuffer ("un");
		tab1.append("deux");
		System.out.println("tab1.taille \t: " + tab1.length());
		//System.out.println("tab2 \t\t: " + Arrays.toString(tab2));

	}

}
