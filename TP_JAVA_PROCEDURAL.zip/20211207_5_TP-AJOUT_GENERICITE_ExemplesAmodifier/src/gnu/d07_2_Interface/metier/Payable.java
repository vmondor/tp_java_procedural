package gnu.d07_2_Interface.metier;

public interface Payable
{
  float getPrix (); // getPrix est implicitement public et abstract
}
