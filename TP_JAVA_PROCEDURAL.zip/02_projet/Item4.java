public class Item4 {
    public static void main(String [] args){
        System.out.println("résultat du calcul : " + (20.1 + 16.8));
    }
}
