public class Item2 {
        public static void main(String [] args){
            int a = 1;
            int b = 1;
            int result = a + b;
            System.out.println(a + " + " + b + " = " + result);
        }
    
}
