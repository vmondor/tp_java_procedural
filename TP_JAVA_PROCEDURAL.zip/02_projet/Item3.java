public class Item3 {
    public static void main(String [] args){
        byte c = 50;
        byte d = 70;
        byte e;
        // System.out.println("valeur de e: " + e);
    }
}
