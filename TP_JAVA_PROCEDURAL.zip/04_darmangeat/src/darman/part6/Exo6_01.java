package darman.part6;

public class Exo6_01 {

	public static void main(String[] args) {
		int[] tableau = new int[7];
		for (int i = 0; i < tableau.length; i++) {
			tableau[i] = 0;
			System.out.println(tableau[i]);
		}

	}

}
