package darman.part6;

public class Exo6_02 {

	public static void main(String[] args) {
		char[] tableau = new char[] {'a', 'e', 'i', 'o', 'u', 'y'};
		for (char value : tableau) {
			System.out.println(value);
		}

	}

}
