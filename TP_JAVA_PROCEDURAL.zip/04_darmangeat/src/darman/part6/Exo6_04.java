package darman.part6;

public class Exo6_04 {

	public static void main(String[] args) {
		int[] tableau = new int[6];
		for(int i = 0; i <= 5; i++) {
			tableau[i] = i * i;
			System.out.println(tableau[i]);
		}
	}

}
