package darman.part1;

public class Exo1_06 {

	public static void main(String[] args) {
		int c = 0;
		int a = c;
		int b = a;
		System.out.println("Valeur de a = " + a);
		System.out.println("Valeur de b = " + b);
		System.out.println("Valeur de c = " + c);
	}

}
