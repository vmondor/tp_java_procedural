package darman.part1;

public class Exo1_03 {

	public static void main(String[] args) {
		/**
		D�but
		A <- 5
		B <- A + 4
		A <- A + 1
		B <- A � 4
		Fin
		**/
		int a = 5;
		int b = a + 4;
		a = a + 1;
		b = a - 4;
		System.out.println("Valeur de a = " + a);
		System.out.println("Valeur de b = " + b);
	}

}
