package darman.part1;

public class Exo1_07 {

	public static void main(String[] args) {
		int a = 0; 
		int b = a;
		int c = b;
		a = c;
	}

}
