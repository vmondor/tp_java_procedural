package darman.part1;

public class Exo1_01 {

	public static void main(String[] args) {

		/**
		Debut
		A <- 1
		B <- A + 3
		A <- 3
		Fin
		 */
		int a = 1;
		int b = a +3;
		a = 3;
		System.out.println("Valeur de a = " + a);
		System.out.println("Valeur de b = " + b);
	}

}