package darman.part1;

public class Exo1_09 {

	public static void main(String[] args) {
		String a = "423";
		String b = "12";
		String c = a + b;
		System.out.println("Valeur de c = " + c);

	}

}
