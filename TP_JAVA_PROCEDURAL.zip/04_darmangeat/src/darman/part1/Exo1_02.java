package darman.part1;

public class Exo1_02 {

	public static void main(String[] args) {
		/**
		D�but
		A <- 5
		B <- 3
		C <- A + B
		A <- 2
		C <- B � A
		Fin
		**/
		int a = 5;
		int b = 3;
		int c = a + b;
		a = 2;
		c = b - a;
		System.out.println("Valeur de a = " + a);
		System.out.println("Valeur de b = " + b);
		System.out.println("Valeur de c = " + c);

	}

}
