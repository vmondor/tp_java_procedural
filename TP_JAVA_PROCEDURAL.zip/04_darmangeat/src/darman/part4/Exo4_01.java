package darman.part4;

public class Exo4_01 {

	public static void main(String[] args) {
		int tutu = 0, toto = 0;
		String tata = "OK";
	if(tutu > toto + 4 || tata == "OK") {
		tutu++;
	} else {
		tutu--;
	}

	}

}
