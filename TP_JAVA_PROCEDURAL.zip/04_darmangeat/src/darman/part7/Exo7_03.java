package darman.part7;

public class Exo7_03 {

	public static void main(String[] args) {
		int [] tableau = new int[] {21, 62, 3, 14, 55};
		for(int i = tableau.length; i > 0; i--) {
			System.out.println(tableau[i-1]);
		}
	}

}
